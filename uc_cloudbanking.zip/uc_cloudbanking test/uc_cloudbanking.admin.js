/**
 * @file
 * Utility functions to display settings summaries on vertical tabs.
 */

(function ($) {

Drupal.behaviors.cloudbankingAdminFieldsetSummaries = {
  attach: function (context) {
    $('fieldset#edit-cc-security', context).drupalSetSummary(function(context) {
      return Drupal.t('Encryption key path') + ': '
        + $('#edit-uc-cloudbanking-encryption-path', context).val();
    });

  }
};

})(jQuery);
